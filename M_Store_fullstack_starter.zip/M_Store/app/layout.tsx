import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "M STORE — Online Shop", description: "Өдөр тутмын хэрэгцээт бүх зүйл нэг дор." };
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return <html lang="mn"><body>{children}</body></html>;
}
