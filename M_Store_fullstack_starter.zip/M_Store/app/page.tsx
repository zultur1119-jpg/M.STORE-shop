'use client';
import { useEffect, useMemo, useState } from "react";
type Product={id:string;name:string;slug:string;description:string;category:string;price_mnt:number;compare_at_price_mnt:number|null;image_url:string|null;stock:number};
const money=(n:number)=>new Intl.NumberFormat('mn-MN').format(n)+' ₮';
const cats=[['Бүгд','✳️'],['Электроник','🎧'],['Хувцас','👕'],['Гоо сайхан','🧴'],['Гэр ахуй','🏠'],['Аксессуар','⌚']];
export default function Home(){
 const [products,setProducts]=useState<Product[]>([]),[cat,setCat]=useState('Бүгд'),[q,setQ]=useState(''),[cart,setCart]=useState<Record<string,number>>({});
 useEffect(()=>{fetch('/api/products').then(r=>r.json()).then(d=>setProducts(d.products||[])).catch(()=>setProducts([]));},[]);
 const shown=useMemo(()=>products.filter(p=>(cat==='Бүгд'||p.category===cat)&&p.name.toLowerCase().includes(q.toLowerCase())),[products,cat,q]);
 const count=Object.values(cart).reduce((a,b)=>a+b,0);
 return <><div className="bar">УЛААНБААТАР БОЛОН ОРОН НУТАГТ ХҮРГЭЛТТЭЙ · M STORE</div><nav className="nav"><a className="logo" href="/">M<i>.</i>STORE</a><div className="links"><a href="#home">Нүүр</a><a href="#categories">Ангилал</a><a href="#products">Бараанууд</a><a href="/admin">Админ</a></div><button onClick={()=>alert('Сагсанд '+count+' бараа байна')}>Сагс · {count}</button></nav>
 <section className="hero" id="home"><div><div className="eyebrow">M STORE · CURATED FOR YOU</div><h1>Өдөр бүрийн<br/>сонголт.</h1><p>Таны өдөр тутмын хэрэгцээт бүх зүйл нэг дор. Чанартай бүтээгдэхүүн, хялбар худалдан авалт.</p><a className="cta" href="#products">БАРАА ҮЗЭХ ↗</a></div><div className="heroMark">M.</div></section>
 <main className="container"><div className="head" id="categories"><div><div className="eyebrow">EXPLORE</div><h2>Ангиллаар сонгох</h2></div></div><div className="cats">{cats.map(([name,icon])=><button key={name} className={'cat '+(cat===name?'active':'')} onClick={()=>setCat(name)}><span>{icon}</span>{name}</button>)}</div>
 <div className="head" id="products"><div><div className="eyebrow">THE COLLECTION</div><h2>Бараанууд</h2></div><div className="muted">{shown.length} бүтээгдэхүүн</div></div><div className="tools"><input placeholder="Бараа хайх..." value={q} onChange={e=>setQ(e.target.value)}/></div><div className="grid">{shown.length?shown.map(p=><article className="card" key={p.id}><div className="image">{p.image_url?<img src={p.image_url} alt={p.name} style={{width:'100%',height:'100%',objectFit:'cover'}}/>:<>🛍️</>}</div><div className="name">{p.name}</div><div className="muted">{p.category} · Үлдэгдэл {p.stock}</div><p className="price">{money(p.price_mnt)} <button className="add" onClick={()=>setCart(c=>({...c,[p.id]:(c[p.id]||0)+1}))}>+ САГС</button></p></article>):<div className="empty">Одоогоор бараа нэмэгдээгүй байна. Админ хэсгээс бараа оруулна уу.</div>}</div></main>
 <footer className="footer"><a className="logo" href="/">M<i>.</i>STORE</a><p>Өдөр тутмын хэрэгцээт бүх зүйл нэг дор.</p><p>Төлбөр: QPay · Хүргэлт: УБ болон орон нутаг</p><p>© 2026 M STORE</p></footer></>;
}
