import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
export async function GET() {
  if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    return NextResponse.json({ products: [], setupRequired: true });
  }
  const db=createAdminClient();
  const {data,error}=await db.from("products").select("*").eq("is_active",true).order("created_at",{ascending:false});
  if(error) return NextResponse.json({error:"Бараа уншихад алдаа гарлаа."},{status:500});
  return NextResponse.json({products:data||[]});
}
