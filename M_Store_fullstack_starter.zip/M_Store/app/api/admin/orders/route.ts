import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
export async function GET(){
 if(!await requireAdmin()) return NextResponse.json({error:"Unauthorized"},{status:401});
 const db=createAdminClient();
 const {data,error}=await db.from("orders").select("*").order("created_at",{ascending:false}).limit(100);
 return error ? NextResponse.json({error:"Захиалга уншихад алдаа гарлаа."},{status:500}) : NextResponse.json({orders:data||[]});
}
