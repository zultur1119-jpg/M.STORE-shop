import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
export async function GET(){const user=await requireAdmin();return user?NextResponse.json({ok:true}):NextResponse.json({error:"Unauthorized"},{status:401});}
