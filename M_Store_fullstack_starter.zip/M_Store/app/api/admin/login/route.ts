import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
export async function POST(req:Request){
 const {email,password}=await req.json();
 const supabase=await createClient();
 const {data,error}=await supabase.auth.signInWithPassword({email,password});
 if(error||!data.user)return NextResponse.json({error:"Нэвтрэх мэдээлэл буруу байна."},{status:401});
 if(data.user.id!==process.env.ADMIN_USER_ID){await supabase.auth.signOut();return NextResponse.json({error:"Админ эрхгүй хэрэглэгч байна."},{status:403});}
 return NextResponse.json({message:"Амжилттай нэвтэрлээ."});
}
