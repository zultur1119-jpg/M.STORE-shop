import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";

// Verify every callback against QPay's payment-check endpoint.
// Confirm the exact callback payload with QPay for this merchant account before production.
export async function POST(req:Request){
 const body=await req.json().catch(()=>null);
 const invoiceId=body?.invoice_id;
 if(!invoiceId)return NextResponse.json({error:"Missing invoice_id"},{status:400});
 const db=createAdminClient();
 const {data:order}=await db.from("orders").select("id").eq("qpay_invoice_id",invoiceId).maybeSingle();
 if(!order)return NextResponse.json({error:"Order not found"},{status:404});
 // Do not mark an order paid from an unverified callback alone.
 const auth=Buffer.from(`${process.env.QPAY_CLIENT_ID}:${process.env.QPAY_CLIENT_SECRET}`).toString("base64");
 const tr=await fetch(`${process.env.QPAY_BASE_URL}/v2/auth/token`,{method:"POST",headers:{Authorization:`Basic ${auth}`}});
 if(!tr.ok)return NextResponse.json({error:"QPay auth failed"},{status:502});
 const token=await tr.json();
 const check=await fetch(`${process.env.QPAY_BASE_URL}/v2/payment/check`,{method:"POST",headers:{Authorization:`Bearer ${token.access_token}`,"Content-Type":"application/json"},body:JSON.stringify({object_type:"INVOICE",object_id:invoiceId})});
 if(!check.ok)return NextResponse.json({error:"Payment check failed"},{status:502});
 const payment=await check.json();
 const paid=Number(payment.count)>0 && Array.isArray(payment.rows) && payment.rows.some((r:any)=>r.payment_status==="PAID");
 if(paid)await db.from("orders").update({payment_status:"paid",order_status:"confirmed"}).eq("id",order.id);
 return NextResponse.json({ok:true,paid});
}
