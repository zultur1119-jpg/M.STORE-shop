import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";

type Item={productId:string;quantity:number};
const json=(message:string,status=400)=>NextResponse.json({error:message},{status});

export async function POST(req:Request){
 try{
  const body=await req.json() as {customerName:string;phone:string;address:string;note?:string;items:Item[]};
  if(!body.customerName?.trim()||!body.phone?.trim()||!body.address?.trim()||!Array.isArray(body.items)||!body.items.length) return json("Захиалгын мэдээлэл дутуу байна.");
  if(!process.env.QPAY_BASE_URL||!process.env.QPAY_CLIENT_ID||!process.env.QPAY_CLIENT_SECRET||!process.env.QPAY_INVOICE_CODE) return json("QPay merchant тохиргоо хийгдээгүй байна.",503);
  const db=createAdminClient();
  const ids=[...new Set(body.items.map(i=>i.productId))];
  const {data:products,error}=await db.from("products").select("id,name,price_mnt,stock,is_active").in("id",ids);
  if(error||!products||products.length!==ids.length) return json("Барааны мэдээлэл олдсонгүй.");
  const normalized=body.items.map(i=>({...i,quantity:Math.max(1,Math.min(20,Math.floor(i.quantity)))}));
  for(const i of normalized){const p=products.find(x=>x.id===i.productId);if(!p?.is_active||p.stock<i.quantity)return json("Барааны үлдэгдэл хүрэлцэхгүй байна.");}
  const subtotal=normalized.reduce((s,i)=>s+products.find(p=>p.id===i.productId)!.price_mnt*i.quantity,0);
  const orderNumber="MS"+Date.now().toString().slice(-9);
  const auth=Buffer.from(`${process.env.QPAY_CLIENT_ID}:${process.env.QPAY_CLIENT_SECRET}`).toString("base64");
  const tokenRes=await fetch(`${process.env.QPAY_BASE_URL}/v2/auth/token`,{method:"POST",headers:{Authorization:`Basic ${auth}`}});
  if(!tokenRes.ok)return json("QPay баталгаажуулалт амжилтгүй. Merchant тохиргоогоо шалгана уу.",502);
  const token=await tokenRes.json();
  const invoiceRes=await fetch(`${process.env.QPAY_BASE_URL}/v2/invoice`,{method:"POST",headers:{Authorization:`Bearer ${token.access_token}`,"Content-Type":"application/json"},body:JSON.stringify({
    invoice_code:process.env.QPAY_INVOICE_CODE,sender_invoice_no:orderNumber,invoice_receiver_code:body.phone,
    invoice_description:`M Store захиалга ${orderNumber}`,amount:subtotal,callback_url:`${process.env.NEXT_PUBLIC_SITE_URL}/api/qpay/callback`
  })});
  if(!invoiceRes.ok)return json("QPay нэхэмжлэл үүссэнгүй.",502);
  const invoice=await invoiceRes.json();
  const {error:saveError}=await db.from("orders").insert({order_number:orderNumber,customer_name:body.customerName,phone:body.phone,address:body.address,note:body.note||"",items:normalized.map(i=>({product:products.find(p=>p.id===i.productId)?.name,...i})),subtotal_mnt:subtotal,shipping_mnt:0,total_mnt:subtotal,payment_method:"qpay",qpay_invoice_id:invoice.invoice_id,qpay_invoice_url:invoice.qPay_shortUrl,qpay_qr_text:invoice.qr_text,qpay_qr_image:invoice.qr_image});
  if(saveError)return json("Захиалга хадгалахад алдаа гарлаа.",500);
  return NextResponse.json({orderNumber,invoiceId:invoice.invoice_id,qrImage:invoice.qr_image,qrText:invoice.qr_text,paymentUrl:invoice.qPay_shortUrl,total:subtotal});
 }catch{return json("Серверийн алдаа гарлаа.",500);}
}
