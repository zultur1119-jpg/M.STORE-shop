import { createClient } from "@/lib/supabase/server";
export async function requireAdmin() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user || !process.env.ADMIN_USER_ID || user.id !== process.env.ADMIN_USER_ID) return null;
  return user;
}
