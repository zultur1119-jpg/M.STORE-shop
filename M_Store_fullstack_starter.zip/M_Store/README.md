# M STORE — production starter

This is a deployable full-stack starter for a Mongolian multi-category shop.

## Stack
- Next.js App Router + TypeScript
- Supabase Postgres + Auth (admin access)
- QPay v2 server-side payment integration (credentials required)
- Responsive storefront and protected admin area

## Important
This starter is not live until you create the Supabase project, add environment variables,
configure QPay merchant credentials, deploy it, and point `mstore.shop` DNS at the host.
Never put QPay secrets or Supabase service-role keys in browser code.

## 1. Install
```bash
npm install
cp .env.example .env.local
npm run dev
```

## 2. Supabase
1. Create a Supabase project.
2. Run `supabase/schema.sql` in the SQL editor.
3. Copy Project URL and anon key into `.env.local`.
4. Create your admin user in Supabase Auth.
5. Set that user's UUID in `ADMIN_USER_ID`.

## 3. QPay
Ask QPay for merchant/API access and sandbox credentials first. Add:
- `QPAY_BASE_URL` (sandbox or production URL supplied by QPay)
- `QPAY_CLIENT_ID`
- `QPAY_CLIENT_SECRET`
- `QPAY_INVOICE_CODE`
- `QPAY_CALLBACK_SECRET`

The Merchant V2 API uses Basic Auth with `client_id:client_secret` to obtain a token, then Bearer Auth for invoice/payment endpoints. The server creates invoices and verifies payment after QPay callback. Confirm the exact callback payload/authentication contract with QPay before production; never treat a browser redirect as proof of payment.

## 4. Deploy
Deploy the repository to Vercel (or another Node hosting provider). Add the same environment
variables in the host dashboard. Add `mstore.shop` in the project's Domains settings and follow
the DNS records shown by the host. DNS and domain ownership must be completed by the owner.

## 5. Admin
Open `/admin` and sign in with the Supabase Auth admin account. The initial authorization is
restricted to `ADMIN_USER_ID`. Do not share admin credentials.

## Current scope
- Product listing/search/category filter
- Cart in browser
- Checkout form and QPay invoice creation endpoint
- Supabase product/order schema
- Protected product/order admin page
- Product/order management API starter

Before accepting real money, test sandbox payment, callback handling, refunds/cancellations,
order status transitions, shipping fees, privacy notice, terms, and Mongolian consumer/tax
requirements. This repository does not include real merchant credentials or create a QPay
merchant account.
