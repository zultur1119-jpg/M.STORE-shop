create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  description text not null default '',
  category text not null,
  price_mnt integer not null check (price_mnt >= 0),
  compare_at_price_mnt integer check (compare_at_price_mnt is null or compare_at_price_mnt >= 0),
  image_url text,
  stock integer not null default 0 check (stock >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text unique not null,
  customer_name text not null,
  phone text not null,
  address text not null,
  note text not null default '',
  items jsonb not null,
  subtotal_mnt integer not null check (subtotal_mnt >= 0),
  shipping_mnt integer not null default 0 check (shipping_mnt >= 0),
  total_mnt integer not null check (total_mnt >= 0),
  payment_method text not null default 'qpay',
  payment_status text not null default 'pending' check (payment_status in ('pending','paid','failed','refunded')),
  order_status text not null default 'new' check (order_status in ('new','confirmed','packing','shipped','completed','cancelled')),
  qpay_invoice_id text,
  qpay_invoice_url text,
  qpay_qr_text text,
  qpay_qr_image text,
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;
alter table public.orders enable row level security;

drop policy if exists "Public can view active products" on public.products;
create policy "Public can view active products" on public.products for select using (is_active = true);

-- Orders and product mutations are server-side only via service role.
-- Never expose SUPABASE_SERVICE_ROLE_KEY to the browser.
